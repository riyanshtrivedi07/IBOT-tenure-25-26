NAME : RIYANSH TRIVEDI

FINAL TEST ACCURACY : 98.43%

LEARNING RATE SCHEDULER : ReduceLROnPlateau

PROBLEMS FACED :
1)It took too much time to train the model

2)I was unable to display 5 correct predictions and 5 incorrect but I somehow managed to write code for the same

3)Also i have merged the evaluation script with training script.
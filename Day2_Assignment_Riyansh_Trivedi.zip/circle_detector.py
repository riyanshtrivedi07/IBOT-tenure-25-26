import cv2
import numpy as np
import matplotlib.pyplot as plt


def preprocess_image(image_path):
    """Load and preprocess the image for circle detection."""
    image = cv2.imread(image_path)
    # Check if image is loaded properly
    if image is None:
        raise ValueError("Image not found or unable to load.")
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # Apply Gaussian blur to reduce noise and improve circle detection
    blurred = cv2.GaussianBlur(gray, (9, 9), 2)
    # Histogram equalization to enhance contrast
    blurred = cv2.equalizeHist(blurred)
    return image, blurred

def detect_circles(preprocessed_image, dp=1.2, min_dist=50, param1=50, param2=70, min_radius=0, max_radius=100):
    """Detect circles in the preprocessed image using Hough Circle Transform."""
    # Detect circles using Hough Circle Transform
    circles = cv2.HoughCircles(preprocessed_image, 
                               cv2.HOUGH_GRADIENT, 
                               dp, 
                               min_dist, 
                               param1=param1, 
                               param2=param2, 
                               minRadius=min_radius, 
                               maxRadius=max_radius)
    # If circles are detected, round their values and convert to uint16
    if circles is not None:
        circles = np.uint16(np.around(circles))
    return circles

def visualize_circles(original_image, circles, save_path=None):

    """Visualize detected circles on the original image."""
    # Create a copy of the original image to annotate
    output_image = original_image.copy()
    # Draw detected circles
    if circles is not None:
        for i in circles[0, :]:
            # Draw the outer circle
            cv2.circle(output_image, (i[0], i[1]), i[2], (0, 255, 0), 2)
            # Draw the center of the circle
            cv2.circle(output_image, (i[0], i[1]), 2, (0, 0, 255), 3)
            # Label circle with its radius and ID
            cv2.putText(output_image, f'ID:{i[2]} R:{i[2]}', (i[0]-40, i[1]-10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)
    # Save the output image if a path is provided
    if save_path:
        cv2.imwrite(save_path, output_image)
    return output_image

def calculate_statistics(circles):
    """Calculate statistics of detected circles."""
    # If no circles detected, return None
    if circles is None:
        return None
    # Extract radii of detected circles
    radii = circles[0, :, 2]
    # Calculate statistics
    stats = {
        'count': len(radii),
        'mean_radius': np.mean(radii),
        'std_radius': np.std(radii),
        'min_radius': np.min(radii),
        'max_radius': np.max(radii)
    }
    return stats

def preprocess_image_from_frame(frame):
    """Preprocess a video frame for circle detection."""
    # Convert to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # Apply Gaussian blur to reduce noise and improve circle detection
    blurred = cv2.GaussianBlur(gray, (9, 9), 2)
    # Histogram equalization to enhance contrast
    blurred = cv2.equalizeHist(blurred)
    return frame, blurred

def video_frame_processor(frame):
    """Process a video frame to detect and visualize circles."""
    original_image, preprocessed_image = preprocess_image_from_frame(frame)
    circles = detect_circles(preprocessed_image)
    output_image = visualize_circles(original_image, circles)
    return output_image

def video_circle_detector(video_path, output_path=None, fourcc=cv2.VideoWriter_fourcc(*'XVID')):
    """Detect circles in a video and optionally save the output video."""
    cap = cv2.VideoCapture(video_path)
    out = None
    if output_path:
        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        output_frame = video_frame_processor(frame)
        if out:
            out.write(output_frame)
        cv2.imshow('Detected Circles', output_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    if out:
        out.release()
    cv2.destroyAllWindows()

def main(image_path, output_path=None):
    original_image, preprocessed_image = preprocess_image(image_path)
    circles = detect_circles(preprocessed_image)
    output_image = visualize_circles(original_image, circles, save_path=output_path)
    stats = calculate_statistics(circles)
    # Display statistics
    if stats:
        print(stats)
    else:
        print("No circles detected.")
    #Display Input image
    plt.imshow(cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB))
    plt.axis('off')
    plt.show()
    # Display the output image
    plt.imshow(cv2.cvtColor(output_image, cv2.COLOR_BGR2RGB))
    plt.axis('off')
    plt.show()

video_circle_detector('C:\\Users\\RIYANSH TRIVEDI\\IBOT Tenure 2025-26\\myenv\\280602.mp4', 'C:\\Users\\RIYANSH TRIVEDI\\IBOT Tenure 2025-26\\myenv\\output_video.avi')
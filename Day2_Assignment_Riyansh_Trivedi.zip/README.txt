CIRCLE DETECTOR

1)The image file path should be valid.

2)It may detect extra or invalid circles which can be controlled by controlling parameters such as param2, max radius, mindist, dp, etc.

3)Call main function for detecting and displaying output properly instead if you only want to calculate circles call circle_detector function

4)It also processes video and identifies circles but you have to provide valid video path and you may change parameters in case of any discrepancies for the same.